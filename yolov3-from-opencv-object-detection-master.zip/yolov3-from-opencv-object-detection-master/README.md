# yolov3-from-opencv-object-detection

Object detection using yolov3 from OpenCV !

[![Watch the video](https://img.youtube.com/vi/yZ1b3PENhhM/0.jpg)](https://www.youtube.com/watch?v=yZ1b3PENhhM)

## model

You can download the model (config and weights) from [yolo official website](https://pjreddie.com/darknet/yolo/).